var searchData=
[
  ['savetofile',['saveToFile',['../classed_1_1Heap.html#aa2f7cd375a8448b9a7e1f39fbeb26ad4',1,'ed::Heap']]],
  ['setbloodtype',['setBloodType',['../classDonor.html#a7c912c9aaa56559cce5e902dd37a264b',1,'Donor::setBloodType()'],['../classed_1_1InterfaceDonor.html#ae1f257d41c5612ebe21a378440a6df1a',1,'ed::InterfaceDonor::setBloodType()']]],
  ['setdonations',['setDonations',['../classDonor.html#a26f2cc52e3d4088677bd75d87eb18f03',1,'Donor::setDonations()'],['../classed_1_1InterfaceDonor.html#a5042afd92a674ddd6b43402119e1cbd8',1,'ed::InterfaceDonor::setDonations()']]],
  ['setname',['setName',['../classDonor.html#a688ef85940c602cdb805681ca21a7133',1,'Donor::setName()'],['../classed_1_1InterfaceDonor.html#a2759f021088c6002f5e96ba81133f697',1,'ed::InterfaceDonor::setName()']]],
  ['setnumberofelements',['setNumberOfElements',['../classed_1_1Heap.html#ab9b6c2e9fed5cd92fd0542c3a3b5ccab',1,'ed::Heap']]],
  ['setrhfactor',['setRhFactor',['../classDonor.html#ae31a0d0d1c81d8920cbea802d7487013',1,'Donor::setRhFactor()'],['../classed_1_1InterfaceDonor.html#adc1da811d60acf410d7e78a6723018f9',1,'ed::InterfaceDonor::setRhFactor()']]],
  ['setsurname',['setSurname',['../classDonor.html#abac057d301765f5682b4eb57c87988dc',1,'Donor::setSurname()'],['../classed_1_1InterfaceDonor.html#af29535a35a836e344382958e975b6000',1,'ed::InterfaceDonor::setSurname()']]],
  ['subrayado',['SUBRAYADO',['../defines_8hpp.html#a3ab8b4157fd29a2336c702b26a967bb9',1,'defines.hpp']]],
  ['surname_5f',['surname_',['../classDonor.html#a73359adfd1f62a44778cc6da6e6a3ba2',1,'Donor']]]
];
