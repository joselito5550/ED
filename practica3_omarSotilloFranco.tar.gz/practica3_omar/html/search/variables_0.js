var searchData=
[
  ['bloodtype_5f',['bloodType_',['../classDonor.html#ae4043a412a633008e4a12c2b9c9e5b9f',1,'Donor']]]
];
