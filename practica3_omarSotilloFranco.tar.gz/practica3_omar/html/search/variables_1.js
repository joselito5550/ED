var searchData=
[
  ['donations_5f',['donations_',['../classDonor.html#a721f58053d174cb0eb945b748ee9504b',1,'Donor']]]
];
