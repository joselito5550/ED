var searchData=
[
  ['surname_5f',['surname_',['../classDonor.html#a73359adfd1f62a44778cc6da6e6a3ba2',1,'Donor']]]
];
