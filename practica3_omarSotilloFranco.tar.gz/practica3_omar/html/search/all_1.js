var searchData=
[
  ['bloodtype_5f',['bloodType_',['../classDonor.html#ae4043a412a633008e4a12c2b9c9e5b9f',1,'Donor']]],
  ['borrar',['BORRAR',['../defines_8hpp.html#a79bf316fce01e63d76dddcdcbe72ab1c',1,'defines.hpp']]]
];
