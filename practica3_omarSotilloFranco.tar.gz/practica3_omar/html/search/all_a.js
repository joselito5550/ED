var searchData=
[
  ['name_5f',['name_',['../classDonor.html#a479cbbe949cd832a4644ae579143532b',1,'Donor']]],
  ['numberofelements_5f',['numberOfElements_',['../classed_1_1Heap.html#a3c0f6b09e9842aba8851078f8bf082e3',1,'ed::Heap']]]
];
