var searchData=
[
  ['rhfactor_5f',['rhFactor_',['../classDonor.html#a2e5d74605e9cb24b3d62b94c39474a97',1,'Donor']]]
];
