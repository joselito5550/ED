var searchData=
[
  ['header',['HEADER',['../defines_8hpp.html#ab7770a7f0d95e67620ff6ed347a07a56',1,'defines.hpp']]]
];
