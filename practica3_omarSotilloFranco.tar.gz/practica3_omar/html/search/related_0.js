var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classDonor.html#a6f0c6f0c3a26d34941a25ea54aa07284',1,'Donor']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classDonor.html#a2d8a353264e3d89ae2e0f17b3e00f1ab',1,'Donor']]]
];
