var searchData=
[
  ['savetofile',['saveToFile',['../classCustomList.html#a8d9d6bb2ac4f62765f7431e4e947cde6',1,'CustomList::saveToFile()'],['../classDonors.html#aab7ddcf974a87c62711751bf0c814522',1,'Donors::saveToFile()']]],
  ['setbloodtype',['setBloodType',['../classDonor.html#a7c912c9aaa56559cce5e902dd37a264b',1,'Donor::setBloodType()'],['../classed_1_1InterfaceDonor.html#ae1f257d41c5612ebe21a378440a6df1a',1,'ed::InterfaceDonor::setBloodType()']]],
  ['setcurrent',['setCurrent',['../classCustomList.html#a3a5b44e806baf62f0d3080c506aa333a',1,'CustomList']]],
  ['setcursortoposition',['setCursorToPosition',['../classCustomList.html#abcf30a8a7bfd26f7e40b76ae5351ae00',1,'CustomList']]],
  ['setcustomlist',['setCustomList',['../classDonors.html#aae170af66c0c7b457ac386418407f428',1,'Donors']]],
  ['setname',['setName',['../classDonor.html#a688ef85940c602cdb805681ca21a7133',1,'Donor::setName()'],['../classed_1_1InterfaceDonor.html#a2759f021088c6002f5e96ba81133f697',1,'ed::InterfaceDonor::setName()']]],
  ['setnumberofnodes',['setNumberOfNodes',['../classCustomList.html#a4b64bc67bba34432ae9aeb96a6f5b4d2',1,'CustomList']]],
  ['setrhfactor',['setRhFactor',['../classDonor.html#ae31a0d0d1c81d8920cbea802d7487013',1,'Donor::setRhFactor()'],['../classed_1_1InterfaceDonor.html#adc1da811d60acf410d7e78a6723018f9',1,'ed::InterfaceDonor::setRhFactor()']]],
  ['setsurname',['setSurname',['../classDonor.html#abac057d301765f5682b4eb57c87988dc',1,'Donor::setSurname()'],['../classed_1_1InterfaceDonor.html#af29535a35a836e344382958e975b6000',1,'ed::InterfaceDonor::setSurname()']]]
];
