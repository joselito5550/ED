var searchData=
[
  ['apaga',['APAGA',['../defines_8hpp.html#af2815fb445b50124864e3f2f958fac24',1,'defines.hpp']]]
];
