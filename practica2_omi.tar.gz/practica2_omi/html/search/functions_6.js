var searchData=
[
  ['loadfromfile',['loadFromFile',['../classCustomList.html#ab6265bc270924f943ad949d010a4c0e8',1,'CustomList::loadFromFile()'],['../classDonors.html#a1b76f5d68188552e821c5e0ce65ffcd0',1,'Donors::loadFromFile()']]]
];
