var searchData=
[
  ['donor',['donor',['../structNode.html#ab49ea12577335afb08109b294415500f',1,'Node']]]
];
