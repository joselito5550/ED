var searchData=
[
  ['readdonor',['readDonor',['../classDonor.html#ac00bc72a6f4edca9546f0d0998e750c9',1,'Donor']]],
  ['readdonors',['readDonors',['../classDonors.html#a36de39cd0dd0817f6b26ba939bcd900d',1,'Donors']]]
];
