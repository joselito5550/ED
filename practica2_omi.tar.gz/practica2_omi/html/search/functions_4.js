var searchData=
[
  ['getbloodtype',['getBloodType',['../classDonor.html#adf7a39d9e2e1004ccf28b844dd0da2c7',1,'Donor::getBloodType()'],['../classed_1_1InterfaceDonor.html#a0cdf2b2da04fc9e1096c5080ed1f0082',1,'ed::InterfaceDonor::getBloodType()']]],
  ['getcustomlist',['getCustomList',['../classDonors.html#a6b40d64888a6bd0b67894709f655fc38',1,'Donors']]],
  ['getname',['getName',['../classDonor.html#a97dda01cdb61d9861d829b63487b0b6a',1,'Donor::getName()'],['../classed_1_1InterfaceDonor.html#ae82bcaee04a5234cfbb0a8bc67075b74',1,'ed::InterfaceDonor::getName()']]],
  ['getnumberofnodes',['getNumberOfNodes',['../classCustomList.html#a20f95dac26deab968cd61d1ac36e4bde',1,'CustomList']]],
  ['getrhfactor',['getRhFactor',['../classDonor.html#a9d8d7af73c65c4a35f1958205f7733eb',1,'Donor::getRhFactor()'],['../classed_1_1InterfaceDonor.html#af8448a7c7e6d65a1c60ac81ef688de5f',1,'ed::InterfaceDonor::getRhFactor()']]],
  ['getsurname',['getSurname',['../classDonor.html#a36af5a931e2eaf9bc1d39db8b923c795',1,'Donor::getSurname()'],['../classed_1_1InterfaceDonor.html#ae2f327f5dcc2a007afeae2830c986dbb',1,'ed::InterfaceDonor::getSurname()']]]
];
