var searchData=
[
  ['libraries_2ehpp',['libraries.hpp',['../libraries_8hpp.html',1,'']]],
  ['loadfromfile',['loadFromFile',['../classCustomList.html#ab6265bc270924f943ad949d010a4c0e8',1,'CustomList::loadFromFile()'],['../classDonors.html#a1b76f5d68188552e821c5e0ce65ffcd0',1,'Donors::loadFromFile()']]],
  ['lugar',['LUGAR',['../defines_8hpp.html#a1e26748f72802cc32341cc3846db931f',1,'defines.hpp']]]
];
