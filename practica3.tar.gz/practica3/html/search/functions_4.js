var searchData=
[
  ['getdonaciones',['getDonaciones',['../classed_1_1Donante.html#ae0255405dc76a90d2ea383cd8abd4d43',1,'ed::Donante::getDonaciones()'],['../classed_1_1DonanteInterfaz.html#a0e72966c68cab8ccb8da1c493a3a6f56',1,'ed::DonanteInterfaz::getDonaciones()']]],
  ['getgroup',['getGroup',['../classed_1_1Donante.html#a0b1e59193e6c887a7232d48b71bfae33',1,'ed::Donante::getGroup()'],['../classed_1_1DonanteInterfaz.html#a094e88f0c9cd5c7391d5c06a09a667a1',1,'ed::DonanteInterfaz::getGroup()']]],
  ['getname',['getName',['../classed_1_1Donante.html#ae76f1220582f41d257d2f91f7addc858',1,'ed::Donante::getName()'],['../classed_1_1DonanteInterfaz.html#acc116c503c26b5dee7c8982e56e5cd59',1,'ed::DonanteInterfaz::getName()']]],
  ['getrh',['getRH',['../classed_1_1Donante.html#aed957d321e76a3a907849d4cf0f438ee',1,'ed::Donante::getRH()'],['../classed_1_1DonanteInterfaz.html#a3607867d874ea4fe71813acb41a0b0ef',1,'ed::DonanteInterfaz::getRH()']]],
  ['getsecondname',['getSecondName',['../classed_1_1Donante.html#ace0406348e755517d3e80ceff18a2f59',1,'ed::Donante::getSecondName()'],['../classed_1_1DonanteInterfaz.html#ad00f542962f6585da7b465c48e65a6e9',1,'ed::DonanteInterfaz::getSecondName()']]]
];
