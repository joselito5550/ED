var searchData=
[
  ['donante',['Donante',['../classed_1_1Donante.html',1,'ed']]],
  ['donanteinterfaz',['DonanteInterfaz',['../classed_1_1DonanteInterfaz.html',1,'ed']]]
];
