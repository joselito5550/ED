var searchData=
[
  ['colors_2ehpp',['colors.hpp',['../colors_8hpp.html',1,'']]]
];
