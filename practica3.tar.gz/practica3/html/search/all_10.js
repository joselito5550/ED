var searchData=
[
  ['warning',['WARNING',['../colors_8hpp.html#a5cb439d9f933fde4cf23caa370c030e7',1,'colors.hpp']]],
  ['writedonante',['writeDonante',['../classed_1_1Donante.html#a9d38e1caacf3dee07477fb49da65d65e',1,'ed::Donante']]]
];
