var searchData=
[
  ['okblue',['OKBLUE',['../colors_8hpp.html#ad9f51d85a4d6d80cd00f6a3461bb183f',1,'colors.hpp']]],
  ['okgreen',['OKGREEN',['../colors_8hpp.html#a385c3e1e3d690c32ec87a16e6422d922',1,'colors.hpp']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classed_1_1Donante.html#ab52eb93adf74c23cd988ea8868a08fa0',1,'ed::Donante']]],
  ['operator_3c_3d',['operator&lt;=',['../classed_1_1Donante.html#aa6c68c52b4e36454fae3fc252904fb7a',1,'ed::Donante']]],
  ['operator_3d',['operator=',['../classed_1_1Donante.html#ac517a0b7d0110ded5730241ca1357c1b',1,'ed::Donante']]],
  ['operator_3d_3d',['operator==',['../classed_1_1Donante.html#a4335aaf566fe258aa97dbe83becc45a0',1,'ed::Donante']]],
  ['operator_3e_3d',['operator&gt;=',['../classed_1_1Donante.html#a55423d33ae333c344b079eadf71d1cbe',1,'ed::Donante']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classed_1_1Donante.html#acbd1fb64ad57f44d7c558c5035f5792a',1,'ed::Donante']]]
];
