var searchData=
[
  ['borrar',['BORRAR',['../macros_8hpp.html#a79bf316fce01e63d76dddcdcbe72ab1c',1,'macros.hpp']]],
  ['borrarmonticulo',['borrarMonticulo',['../classed_1_1Monticulo.html#a167e014da42bf6cb97834feb9cb26087',1,'ed::Monticulo']]]
];
