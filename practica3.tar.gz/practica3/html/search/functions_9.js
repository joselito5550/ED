var searchData=
[
  ['setgroup',['setGroup',['../classed_1_1Donante.html#a8e8d2ac356b88e9a83b6a3a573eb76af',1,'ed::Donante::setGroup()'],['../classed_1_1DonanteInterfaz.html#a1b03ede416eb0ca704180091590d185d',1,'ed::DonanteInterfaz::setGroup()']]],
  ['setname',['setName',['../classed_1_1Donante.html#a149c2f94803ea99ca0d322e1f54eb3e9',1,'ed::Donante::setName()'],['../classed_1_1DonanteInterfaz.html#a368e9dadd91e8505ea63997ec8399847',1,'ed::DonanteInterfaz::setName()']]],
  ['setrh',['setRH',['../classed_1_1Donante.html#ae0c5eed15e7f42de44bde8405e92f598',1,'ed::Donante::setRH()'],['../classed_1_1DonanteInterfaz.html#abca20fa89aabd5d680ed16001b48b1fb',1,'ed::DonanteInterfaz::setRH()']]],
  ['setsecondname',['setSecondName',['../classed_1_1Donante.html#a28b1027f7ceddd66a48a5aad0ead0c43',1,'ed::Donante::setSecondName()'],['../classed_1_1DonanteInterfaz.html#a9f400be5262f8c75d136ea6bec7c6ee6',1,'ed::DonanteInterfaz::setSecondName()']]]
];
