var searchData=
[
  ['operator_3c_3d',['operator&lt;=',['../classed_1_1Donante.html#aa6c68c52b4e36454fae3fc252904fb7a',1,'ed::Donante']]],
  ['operator_3d',['operator=',['../classed_1_1Donante.html#ac517a0b7d0110ded5730241ca1357c1b',1,'ed::Donante']]],
  ['operator_3d_3d',['operator==',['../classed_1_1Donante.html#a4335aaf566fe258aa97dbe83becc45a0',1,'ed::Donante']]],
  ['operator_3e_3d',['operator&gt;=',['../classed_1_1Donante.html#a55423d33ae333c344b079eadf71d1cbe',1,'ed::Donante']]]
];
