var searchData=
[
  ['insertar',['insertar',['../classed_1_1Monticulo.html#a573f0043ee88445d6b6a61d988703410',1,'ed::Monticulo::insertar()'],['../classed_1_1MonticuloInterfaz.html#a3800d68ce174f398a3ab0c6eca4e855f',1,'ed::MonticuloInterfaz::insertar()']]]
];
