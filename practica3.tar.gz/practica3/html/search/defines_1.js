var searchData=
[
  ['borrar',['BORRAR',['../macros_8hpp.html#a79bf316fce01e63d76dddcdcbe72ab1c',1,'macros.hpp']]]
];
