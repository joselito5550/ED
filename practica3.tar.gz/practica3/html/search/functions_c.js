var searchData=
[
  ['writedonante',['writeDonante',['../classed_1_1Donante.html#a9d38e1caacf3dee07477fb49da65d65e',1,'ed::Donante']]]
];
