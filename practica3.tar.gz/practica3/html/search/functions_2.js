var searchData=
[
  ['deletecima',['deleteCima',['../classed_1_1Monticulo.html#a34628b3b1210e6d4f5e240ef0e0c0a42',1,'ed::Monticulo::deleteCima()'],['../classed_1_1MonticuloInterfaz.html#a27f0c644317d820494a28459d913bc8f',1,'ed::MonticuloInterfaz::deleteCima()']]]
];
