var searchData=
[
  ['readdonante',['readDonante',['../classed_1_1Donante.html#a82deb00969394d9b5c85c36c3256d4d4',1,'ed::Donante']]]
];
