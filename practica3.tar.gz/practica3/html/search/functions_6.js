var searchData=
[
  ['modify',['modify',['../classed_1_1Donante.html#a86a221eec5fc5800f51a96d732c80124',1,'ed::Donante']]]
];
