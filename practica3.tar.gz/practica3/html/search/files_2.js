var searchData=
[
  ['librerias_2ehpp',['librerias.hpp',['../librerias_8hpp.html',1,'']]]
];
