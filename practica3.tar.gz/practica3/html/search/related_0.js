var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classed_1_1Donante.html#ab52eb93adf74c23cd988ea8868a08fa0',1,'ed::Donante']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classed_1_1Donante.html#acbd1fb64ad57f44d7c558c5035f5792a',1,'ed::Donante']]]
];
