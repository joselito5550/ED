var searchData=
[
  ['deletecima',['deleteCima',['../classed_1_1Monticulo.html#a34628b3b1210e6d4f5e240ef0e0c0a42',1,'ed::Monticulo::deleteCima()'],['../classed_1_1MonticuloInterfaz.html#a27f0c644317d820494a28459d913bc8f',1,'ed::MonticuloInterfaz::deleteCima()']]],
  ['donante',['Donante',['../classed_1_1Donante.html',1,'ed']]],
  ['donante_2ehpp',['Donante.hpp',['../Donante_8hpp.html',1,'']]],
  ['donanteinterfaz',['DonanteInterfaz',['../classed_1_1DonanteInterfaz.html',1,'ed']]],
  ['donanteinterfaz_2ehpp',['DonanteInterfaz.hpp',['../DonanteInterfaz_8hpp.html',1,'']]]
];
