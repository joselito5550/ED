var searchData=
[
  ['warning',['WARNING',['../colors_8hpp.html#a5cb439d9f933fde4cf23caa370c030e7',1,'colors.hpp']]]
];
