var searchData=
[
  ['librerias_2ehpp',['librerias.hpp',['../librerias_8hpp.html',1,'']]],
  ['lugar',['LUGAR',['../macros_8hpp.html#a1e26748f72802cc32341cc3846db931f',1,'macros.hpp']]]
];
