var searchData=
[
  ['vertex_2ehpp',['vertex.hpp',['../vertex_8hpp.html',1,'']]]
];
