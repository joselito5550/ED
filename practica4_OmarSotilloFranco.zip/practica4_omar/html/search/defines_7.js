var searchData=
[
  ['okblue',['OKBLUE',['../defines_8hpp.html#ad9f51d85a4d6d80cd00f6a3461bb183f',1,'defines.hpp']]],
  ['okgreen',['OKGREEN',['../defines_8hpp.html#a385c3e1e3d690c32ec87a16e6422d922',1,'defines.hpp']]]
];
