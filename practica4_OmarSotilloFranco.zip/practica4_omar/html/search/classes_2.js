var searchData=
[
  ['vertex',['Vertex',['../classedi_1_1Vertex.html',1,'edi']]]
];
