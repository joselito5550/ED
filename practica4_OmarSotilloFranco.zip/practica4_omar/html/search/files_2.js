var searchData=
[
  ['edge_2ehpp',['edge.hpp',['../edge_8hpp.html',1,'']]]
];
