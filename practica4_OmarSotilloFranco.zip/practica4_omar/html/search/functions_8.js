var searchData=
[
  ['makedirected',['makeDirected',['../classedi_1_1GraphMatrix.html#ae042de41a5993a3a3b49d2188ed4cbd2',1,'edi::GraphMatrix']]],
  ['makeundirected',['makeUndirected',['../classedi_1_1GraphMatrix.html#a86ef05a3cbe484725b0bb6af725cfe24',1,'edi::GraphMatrix']]]
];
