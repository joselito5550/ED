var searchData=
[
  ['edge',['Edge',['../classedi_1_1Edge.html',1,'edi']]]
];
