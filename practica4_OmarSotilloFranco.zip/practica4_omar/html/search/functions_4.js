var searchData=
[
  ['getdata',['getData',['../classedi_1_1Edge.html#afe9a654743dce5982f3ae611899ac20c',1,'edi::Edge::getData()'],['../classedi_1_1Vertex.html#a6d4f5bef9306c91ccfa6beeee12a9216',1,'edi::Vertex::getData()']]],
  ['getlabel',['getLabel',['../classedi_1_1Vertex.html#a032637afec6496f48284b463a23ce542',1,'edi::Vertex']]],
  ['goto',['goTo',['../classedi_1_1GraphMatrix.html#a7ca8e3444dc2a916391a9e5844c7afb1',1,'edi::GraphMatrix::goTo(const Vertex &amp;u)'],['../classedi_1_1GraphMatrix.html#ab1123174f109935506edcfe8f1e3b1cc',1,'edi::GraphMatrix::goTo(const unsigned int &amp;idx)']]],
  ['graphmatrix',['GraphMatrix',['../classedi_1_1GraphMatrix.html#a190aa459192a271a0d23d7d17b61d820',1,'edi::GraphMatrix']]]
];
