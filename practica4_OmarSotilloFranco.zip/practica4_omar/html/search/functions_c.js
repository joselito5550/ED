var searchData=
[
  ['vertexsmaller',['VertexSmaller',['../algorithms_8hpp.html#a286695ca51eb92050dca5b904f27c209',1,'algorithms.cpp']]]
];
