var searchData=
[
  ['getcoef',['getCoef',['../classed_1_1Monomio.html#a854e70095390390529cb8dc9e452b8b7',1,'ed::Monomio']]],
  ['getexp',['getExp',['../classed_1_1Monomio.html#aac34c36d80ca652b93d9aee5e230a466',1,'ed::Monomio']]],
  ['getgrado',['getGrado',['../classed_1_1Polinomio.html#a6652a2361f03daf45b38a97e8b146d15',1,'ed::Polinomio']]],
  ['getmon',['getMon',['../classed_1_1Polinomio.html#a5bb00eac1c6105992e4facb276568319',1,'ed::Polinomio']]],
  ['getnummon',['getNumMon',['../classed_1_1Polinomio.html#a778988ce7466dde1d73cce206625b43c',1,'ed::Polinomio']]]
];
