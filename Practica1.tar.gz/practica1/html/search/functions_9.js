var searchData=
[
  ['setcoef',['setCoef',['../classed_1_1Monomio.html#aace55ae66423fd9cc0dfcfbf302db635',1,'ed::Monomio']]],
  ['setexp',['setExp',['../classed_1_1Monomio.html#a1bd02f016ac38b1ffaadf4955f91264b',1,'ed::Monomio']]],
  ['setgrado',['setGrado',['../classed_1_1Polinomio.html#a06a1d58a8cd14b9fedf52960e304f636',1,'ed::Polinomio']]],
  ['setnummon',['setNumMon',['../classed_1_1Polinomio.html#ac97fa359ea885e984e0e69f69155d89a',1,'ed::Polinomio']]]
];
