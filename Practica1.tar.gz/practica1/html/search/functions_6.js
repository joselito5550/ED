var searchData=
[
  ['monomio',['Monomio',['../classed_1_1Monomio.html#ac4d5082a7918cd436090855a729337d9',1,'ed::Monomio::Monomio()'],['../classed_1_1Monomio.html#a2c3fdd06374813306e45f2b81af4c64e',1,'ed::Monomio::Monomio(const int &amp;exp, const double &amp;coef)'],['../classed_1_1Monomio.html#a1a40fcd30108ec98eaec208150455337',1,'ed::Monomio::Monomio(const Monomio &amp;m)']]]
];
