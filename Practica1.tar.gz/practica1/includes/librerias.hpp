
#ifndef __LIBRARIES_HPP_
# define __LIBRARIES_HPP_


#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <string>
#include <vector>
#include <list>
#include <cmath>
#include "colors.hpp"
#include "MonoInterfaz.hpp"
#include "Monomio.hpp"
#include "PolinomioInterfaz.hpp"
#include "Polinomio.hpp"


#endif // ifndef __LIBRARIES_HPP_
